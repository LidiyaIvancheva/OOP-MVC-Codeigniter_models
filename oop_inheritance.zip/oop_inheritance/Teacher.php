<?php
	include('includes.php');

	class Teacher extends SchoolPeople {
		public $education;
		public $subject;

	}
?><?php $_POST[]; ?>