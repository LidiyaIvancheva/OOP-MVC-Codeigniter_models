<?php 
	include('includes.php');
// Teacher extends SchoolPeople
// Student extends SchoolPeople
	class SchoolPeople {
		var $name;
		var $phone;

		public function __construct($name, $phone) {
			$this->name = $name;
			$this->phone = $phone;
		}

		public function getInfo() {
			echo "Name: " . $this->name;
			echo "Phone: " . $this->phone;
		}

	}