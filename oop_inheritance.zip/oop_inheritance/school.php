<?php 
	
	// include_once('includes.php');

?>

<!DOCTYPE html>
<html>
	<head>

	</head>

	<body>
		<h2>Add new teacher</h2>
		<form action="" method="post">
			Name: 
			<input type="text" name="name"><br>
			Phone:
			<input type="text" name="phone"><br>
			Education: 
			<input type="text" name="education"><br>
			Subject:
			<input type="text" name="subject"><br>
			<input type="submit" value="Add teacher">
		</form>
	</body>
</html>