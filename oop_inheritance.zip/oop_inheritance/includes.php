<?php 
	
	include('SchoolPeople.php');
	include('Teacher.php');
